Telescope.prototype.createRedirection = function (redirectConfig) {
  $(redirectConfig.id).bind("click", function () {
    window.location.replace(redirectConfig.redirectPath);
  });
};

Telescope.prototype.addRedirection = function (id, redirectPath) {
  var redirectConfig = {
    id: id,
    redirectPath: redirectPath,
  };
  var redirection = this.createRedirection(redirectConfig);
  this.redirections.push(redirection);
};

Telescope.prototype.redirect = function (url) {
  window.location.href = url;
}

Telescope.prototype.initSearchBar = function (id) {
  $(id).keypress(function (e) {
    if (e.which == 13) {
      e.preventDefault();
      window.location.href = "./search";
      //window.location.href = "http://localhost:3000/?asin=" + $('#name').val();
    }
  });
};
