Telescope.prototype.showConfigurator = function(status){
    $('body').on('keypress', function (e) {
        if(String.fromCharCode(e.which) === "-"){
            $(".configurator").toggleClass("visible");
        }
    });
}
