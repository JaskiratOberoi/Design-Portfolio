Telescope.prototype.initCart = function () {
    this.initCartHandlers = function () {
        $(".add-cart-button").bind("click", function (e) {
            telescope.addToCart(this);
            telescope.showHUC();
        });
        $(".add-bulk-option-button").bind("click", function (e) {
            telescope.addToCart(this);
        })
    };
    this.initCartHandlers();
};
