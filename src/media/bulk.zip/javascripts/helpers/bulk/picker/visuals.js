Telescope.prototype.visuals = function () {

    this.hidePackPickerFirstItemValue = function (inputItem) {
        let firstItem = this.getPackPickerFirstItemValue(inputItem);
        $(firstItem).hide();
    }

    this.setPriceOnSidebar = function (price) {
        $('.sidebar .price .units').text(price[0]);
        $('.sidebar .price .decimals').text(price[1]);
    };

    this.loadSidebarPicker = function (status) {
        if (!status) {
            $(".picker-container .quantity-picker").removeClass("visible-true");
            $(".picker-container select").show();
        }
    };
}