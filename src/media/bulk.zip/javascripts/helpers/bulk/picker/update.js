Telescope.prototype.updatePicker = function () {
    console.log("update");
}