Telescope.prototype.packData = function () {

    this.getPageASIN = function () {
        return $('.detail').attr('data-asin');
    };

    this.getCartASIN = function () {
        let asin = this.getPageASIN();
        return telescope.data.cart.find((el) => el.asin === asin);
    };

    this.addASINtoCart = function () {
        if (!this.getCartASIN()) {
            var title = $('.asin-title').text();
            var thumb = $('.asin-image-content').attr('data-thumb');
            telescope.data.cart.push({
                asin: this.getPageASIN(),
                title: title,
                thumb: thumb,
                bulk: [],
            });
        }
        return this.getCartASIN();
    };

    this.getPackASIN = function (id) {
        let asin = this.getCartASIN();
        return asin.bulk.find((el) => el.id === id);
    }

    this.sortPacks = function () {
        let asin = this.getCartASIN();
        asin.bulk.sort(
            (a, b) => parseFloat(a.unitprice) - parseFloat(b.unitprice)
        );
    }

    this.addPackASINtoCart = function (bulkValue, selectedPack) {
        let asin = this.getCartASIN();
        let id = selectedPack.attr('data-id');
        var bulkItem = this.getPackASIN(id);

        if (!bulkItem) {
            let count = selectedPack.attr('data-count');
            let pack = selectedPack.attr('data-pack');
            let unit = selectedPack.attr('data-unit');
            let totalprice = selectedPack.attr('data-totalprice');
            let unitprice = selectedPack.attr('data-unitprice');
            asin.bulk.push({
                id: id,
                picker: parseInt(bulkValue),
                count: count,
                pack: pack,
                unit: unit,
                totalprice: totalprice,
                unitprice: unitprice,
            });
            bulkItem = this.getPackASIN(id);
        }
        bulkItem.picker = parseInt(bulkValue) || 0;
        this.sortPacks();
        return bulkItem;
    };
}