Telescope.prototype.interaction = function () {

    /** SIDE PICKER HANDLERS */

    this.sidePickerClickHandler = function (_pickerId) {
        $(_pickerId).bind('click', function (e) {
            e.preventDefault();
            $(telescope.qp).addClass('expand');
        });
    }

    this.sidePickerInputClickHandler = function (_pickerId) {
        $(_pickerId + ' input').bind('click', function () {
            $(this).val('');
            let firstItem = $(this).parent().find('.quantity-picker-item').eq(0);
            $(firstItem).hide();
            $(this).parent().addClass('expand');
        });
    }

    this.sidePickerKeyUpHandler = function (_pickerId) {
        $(_pickerId + ' input').keyup(function () {
            let firstItem = $(this).parent().find('.quantity-picker-item').eq(0);
            let selectedValue = parseInt(this.value) || 0;
            if (0 == selectedValue || isNaN(selectedValue)) {
                selectedValue = 1;
            }
            let prev;
            let qpItems = $(this).parent().find('.quantity-picker-item');
            $(firstItem).hide();
            $.each(qpItems, function (index, value) {
                if (index) {
                    var currentValue = parseInt($(value).attr('data-pack'));
                    if (0 == selectedValue || isNaN(selectedValue)) {
                        $(firstItem).hide();
                        return;
                    } else if (currentValue < selectedValue) {
                        $(value).hide();
                    } else if (currentValue == selectedValue) {
                        $(value).hide();
                    } else {
                        if (prev) {
                            let unitprice = $(prev).find('.unitprice-value').text();
                            let subtotal = $(prev).find('.subtotal-value').text();
                            $(firstItem).find('.unitprice-value').text(unitprice);
                            $(firstItem).find('.subtotal-value').text(subtotal);
                            $(firstItem).find('.pack-value').text(selectedValue);
                            $(value).show();
                            $(firstItem).show();
                            return;
                        }
                    }
                    prev = value;
                }
            });
        });
    }

    this.sidePickerChangeHandler = function (_pickerId) {
        $(_pickerId + ' input').change(function () {
            let pickerValue = parseInt($(this).val()) || 0;

            $('.bulk-picker input').each(function (index, value) {
                let picker = index ? 0 : pickerValue;
                $(value).val(picker);
                let selectedPack = $(value).parent().parent().parent().parent();
                telescope.updateBulkDataValue(picker, selectedPack);
                $('.quantity-picker').removeClass('expand');
            });

            telescope.getBulkProposal(parseInt($(this).val()) || 0);
            //let picker = parseInt($(this).val()) || 0;
            //let selectedPack = $($(".size-bulk-pack.active-true .pack")[0]);
            //console.log(selectedPack);
            //telescope.updateBulkDataValue(picker, selectedPack);
        });
    }

    this.sidePickerPackProposalHandler = function (_pickerId) {
        $(".optimal-selection").bind("click", function () {
            let total = parseInt($(_pickerId + ' input').val()) || 0;
            let asin = $('.detail').attr('data-asin');
            let asinItem = telescope.data.cart.find((el) => el.asin === asin);
            telescope.updatePackValues(total, asinItem);
        });
    }

    this.sidePickerItemClickHandler = function (_pickerId) {
        $(_pickerId + ' .quantity-picker-item').bind('click', function () {
            let value = parseInt($(this).attr('data-pack'));

            if (!$(this).parent().parent().hasClass('bulk-picker')) {

                let pickerValue = value;

                $('.bulk-picker input').each(function (index, value) {
                    let picker = index ? 0 : pickerValue;
                    $(value).val(picker);
                    let selectedPack = $(value).parent().parent().parent().parent();
                    telescope.updateBulkDataValue(picker, selectedPack);
                    $('.quantity-picker').removeClass('expand');
                });


                telescope.getBulkProposal(value);
            }
            $('.quantity-picker').removeClass('expand');
        });
    }



    /** PACK PICKER HANDLERS */

    this.getPackPickerFirstItemValue = function (inputItem) {
        return $(inputItem).parent().find('.quantity-picker-item').eq(0);
    }

    this.packPickerClickHandler = function (inputItem) {
        $(inputItem).find('input').bind('click', function () {
            telescope.hidePackPickerFirstItemValue(inputItem);
            $(".pack-picker .quantity-picker.bulk-picker").removeClass('expand');
            $(this).parent().addClass('expand');
        });
    }

    this.packPickerKeyUpHandler = function (value) {
        $(value).find('input').keyup(function () {
            telescope.hidePackPickerFirstItemValue(value);

            let firstItem = $(this).parent().find('.quantity-picker-item').eq(0);

            let selectedValue = parseInt(this.value);
            if (0 == selectedValue || isNaN(selectedValue)) {
                selectedValue = 1;
            }
            let prev;
            let qpItems = $(this).parent().find('.quantity-picker-item');

            $.each(qpItems, function (index, value) {
                if (index) {
                    var currentValue = parseInt($(value).attr('data-pack'));
                    if (0 == selectedValue || isNaN(selectedValue)) {
                        $(firstItem).hide();
                        return;
                    } else if (currentValue < selectedValue) {
                        $(value).hide();
                    } else if (currentValue == selectedValue) {
                        $(value).hide();
                    } else {
                        if (prev) {
                            $(value).show();
                            let unitprice = $(prev).find('.unitprice-value').text();
                            let subtotal = $(prev).find('.subtotal-value').text();
                            $(firstItem).find('.unitprice-value').text(unitprice);
                            $(firstItem).find('.subtotal-value').text(subtotal);
                            $(firstItem).find('.pack-value').text(selectedValue + "x");
                            $(value).show();
                            $(firstItem).show();
                            return;
                        }
                    }
                    prev = value;
                }
            });
        });
    }

    this.packPickerChangeHandler = function (value) {
        $(value).find('input').change(function () {
            let picker = parseInt($(this).val()) || 0;
            let selectedPack = $(this).parent().parent().parent().parent();
            telescope.updateBulkDataValue(picker, selectedPack);
            $('.quantity-picker').removeClass('expand');
        });
    }

    this.packPickerItemClickHandler = function (value) {
        $(value).find('.quantity-picker-item').bind('click', function () {
            let picker = parseInt($(this).attr('data-pack')) || 0;
            let selectedPack = $(this).parent().parent().parent().parent().parent();
            $(this).parent().parent().find("input").val(picker);
            telescope.updateBulkDataValue(picker, selectedPack);
            
            $('.quantity-picker').removeClass('expand');
        });
    }

    this.packPickerRemoveHandler = function (value) {
        $(value).find(".remove-rows").bind('click', function (e) {
            e.preventDefault();
            let selectedPack = $(this).parent().parent().parent().parent().parent();
            selectedPack.find("input").val(0);
            telescope.updateBulkDataValue(0, selectedPack);
            $('.quantity-picker').removeClass('expand');
            setTimeout(function () { telescope.checkDisabledButtons(); }, 200);
        });
    }

    this.checkPackTitle = function () {
        let total = $('.pack-picker').length;
        let disabled = $('.pack-picker.disabled').length;
        let enabled = total - disabled;
        let bulkItem = telescope.data.cart[0].bulk;
        console.log("LENGTH", total, disabled, enabled);
        let asin = $('.detail').attr('data-asin');
        let asinItem = telescope.data.cart.find((el) => el.asin === asin);
        if ((asinItem)&&(enabled <=1)){
        $.each(this.data.cart, function (index, cartAsin) {
            $.each(cartAsin.bulk, function (index2, bulkItem) {
            if (bulkItem.picker) {
            $(".sidebar-pack-info").text("Arriving in a Single pack");
            $("#bulk-pack p.label span.title").text("Pack of " + bulkItem.pack);
            }
            });
        });
        }else {
            $(".sidebar-pack-info").text("Arriving in Multiple pack sizes");
            $("#bulk-pack p.label span.title").text("Various Packs");
        }
        // if (enabled <= 1) {
        //     $(".sidebar-pack-info").text("Arriving in a Single pack");
        //     $("#bulk-pack p.label span.title").text("Pack of " + telescope.data);
        // } else {
        //     $(".sidebar-pack-info").text("Arriving in Multiple pack sizes");
        //     $("#bulk-pack p.label span.title").text("Multiple Packs");
        // }
    }

    this.checkDisabledButtons = function () {
        $('.bulk-picker').each(function (index, value) {
            var tempInput = $(value).find('input');
            var tempValue = parseInt(tempInput.val());
            $(value).removeClass("expand");
            telescope.checkPackTitle();
            if (!tempValue) {
                $(value).unbind('click').bind('click', function (e) {
                    telescope.hidePackPickerFirstItemValue(tempInput);
                    e.preventDefault();
                    $(this).addClass('expand');
                    $(value).parent().parent().removeClass("disabled");
                });
                $(value).parent().parent().addClass("disabled");
            } else {
                $(value).parent().parent().removeClass("disabled");
            }
        });
    };

    this.initPackQuantityPickers = () => {
        $('.bulk-picker').each(function (index, inputItem) {
            telescope.packPickerClickHandler(inputItem);
            telescope.packPickerKeyUpHandler(inputItem);
            telescope.packPickerChangeHandler(inputItem);
            telescope.packPickerItemClickHandler(inputItem);
            telescope.packPickerRemoveHandler(inputItem);
        });
    };
    this.initPackQuantityPickers();
}