/* eslint-disable no-undef */

Telescope.prototype.quantityPicker = function (_pickerId) {

  this.updateBulkDataValue = function (bulkValue, selectedPack) {
    let price = selectedPack.find('.size-price').text().substring(1).split('.');
    this.setPriceOnSidebar(price);
    let asinItem = this.addASINtoCart();
    this.addPackASINtoCart(bulkValue, selectedPack);
    telescope.updateData();
  };

  this.updatePackSelectorsAndPickers = function (total, asinItem) {
    var optimalConf = [];
    var totalCount = 0;
    this.sortPacks();
    let showPanel = 0;
    $.each(asinItem.bulk, function (_index, cartBulk) {
      let pack = parseInt(cartBulk.pack);
      //var selector = $("select[data-unitprice='" + cartBulk.unit + "']");
      var bulkPicker = $(".bulk-picker[data-unitprice='" + cartBulk.unit + "']");
      let unitPacks = Math.floor(total / pack);
      total -= unitPacks * pack;
      totalCount += unitPacks * pack;
      if (pack > 1)
        if (unitPacks)
          showPanel++;

      if (unitPacks)
        optimalConf.push("<span><b>" + unitPacks + "x</b> Pack of " + pack + "</span>");
      //selector.val(unitPacks);
      //selector.change();
      //bulkPicker.find('input').val(unitPacks);
      //telescope.checkDisabledButtons();
    });
    //optimalConf.reverse();
    $(".optimal-option").empty();
    $(".optimal-option").append(optimalConf);
    $(".optimal-option").append("<p>" + totalCount + " Total Count</p>");
    console.log("----", showPanel);
    if (showPanel)
      $(".optimal-selection").show();
    else
      $(".optimal-selection").hide();
  };

  // init
  telescope.visuals();
  telescope.packData();
  telescope.interaction();



  this.updatePackValues = function (total, asinItem) {
    $.each(asinItem.bulk, function (_index, cartBulk) {
      let pack = parseInt(cartBulk.pack);
      var selector = $("select[data-unitprice='" + cartBulk.unit + "']");
      var bulkPicker = $(".bulk-picker[data-unitprice='" + cartBulk.unit + "']");
      let unitPacks = Math.floor(total / pack);
      total -= unitPacks * pack;
      selector.val(unitPacks);
      selector.change();
      bulkPicker.find('input').val(unitPacks);
      telescope.checkDisabledButtons();
    });
    $(".optimal-selection").hide();
  }



  this.initSidePickerHandlers = function (_pickerId) {
    this.sidePickerClickHandler(_pickerId);
    this.sidePickerInputClickHandler(_pickerId);
    this.sidePickerKeyUpHandler(_pickerId);
    this.sidePickerChangeHandler(_pickerId);
    this.sidePickerPackProposalHandler(_pickerId);
    this.sidePickerItemClickHandler(_pickerId);
  };

  this.initSidePickerHandlers(_pickerId);

  /*$('.size-bulk-count').bind('click', function () {
    if ($(this).attr('data-asin')) {
      window.location.href = './detail?asin=' + $(this).attr('data-asin');
    }
  });*/

  $('.pack select').on('change', function (e) {
    e.preventDefault();
    let picker = parseInt(this.value) || 0;
    let selectedPack = $(this).parent().parent().parent();
    telescope.updateBulkDataValue(picker, selectedPack);
  });

  let asin = $('.detail').attr('data-asin');
  let asinItem = telescope.data.cart.find((el) => el.asin === asin);
  let total = 0;
  if (asinItem) {
    $.each(asinItem.bulk, function (index2, cartBulk) {
      total += parseInt(cartBulk.picker) || 0;
      var tempPicker = $(".size-bulk-pack.active-true .pack[data-pack=" + cartBulk.pack + "]");
      $(tempPicker).find("input").val(cartBulk.picker);
      $(tempPicker).find("input").change();
    });
  } else {
    if ($("*[data-pack='1'] input")) {
      $("*[data-pack='1'] input").val('1');
      $("*[data-pack='1'] input").change();
    }
  }

  console.log("T", total, telescope.data);


  this.mouse_is_inside = false;

  $(document).ready(function () {
    $('.quantity-picker').hover(
      function () {
        telescope.mouse_is_inside = true;
      },
      function () {
        telescope.mouse_is_inside = false;
      }
    );

    $('body').mouseup(function () {
      if (!telescope.mouse_is_inside) {
        $('.expand').removeClass('expand');
        $('.popover').hide();
        telescope.checkDisabledButtons();
      }
    });

    $('.price-title').click(
      function () {
        // console.log("hello");
        if ($('#business-price-info').css('display') === 'none') {
          // $('#business-price-info').css('visibility', 'visible');
          $('#business-price-info').css('display', 'flex');
        }
        else {
          $('#business-price-info').css('display', 'none');
        }

      }
    );
    telescope.checkPackTitle();


    $('.detailsInfo').click(
      function () {
        // console.log("hello");
        if ($('#bulk-details').css('display') === 'none') {
          // $('#bulk-details').css('visibility', 'visible');
          $('#bulk-details').css('display', 'flex');
        }
        else {
          $('#bulk-details').css('display', 'none');
        }

      }
    )


    $('#seller-names').click(
      function () {
        if ($('#seller-details').css('visibility') === 'hidden') {
          $('#seller-details').css('visibility', 'visible');
          $('#seller-details').css('display', 'flex');
        }
        else {
          $('#seller-details').css('visibility', 'hidden');
          $('#seller-details').css('display', 'none');
        }

      }
    )


    $('.discountInfo').click(
      function () {
        // console.log("hello");
        if ($('#bulk-cost-details').css('display') === 'none') {
          // $('#bulk-details').css('visibility', 'visible');
          $('#bulk-cost-details').css('display', 'flex');
        }
        else {
          $('#bulk-cost-details').css('display', 'none');
        }

      }
    )

  });
};
