Telescope.prototype.initSideBarBulkFilter = function (bulkFilterId) {
  var telescope = this;
  telescope.filters.bulk = [
    {
      name: "unit",
      status: false,
    },
    {
      name: "case",
      status: false,
    },
    {
      name: "pallet",
      status: false,
    },
  ];

  function updateAsins() {
    if (telescope.filters.bulk.some((item) => item.status === true)) {
      var filterCollection = telescope.filters.bulk.filter(
        (item) => item.status === true
      );
      $(".carrousel-asin").hide();
      $.each(filterCollection, function (index, value) {
        $(".bulk-" + value.name).show();
      });
    } else {
      $(".carrousel-asin").show();
    }
  }

  $("#" + bulkFilterId + " li i").bind("click", function (e) {
    var filterValue = $(this).attr("data-tag");
    var filterItem = telescope.filters.bulk.filter(
      (item) => item.name === filterValue
    );
    filterItem[0].status = !filterItem[0].status;
    updateAsins();
  });
};
