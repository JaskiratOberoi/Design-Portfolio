/* eslint-disable no-undef */
var originalData = {
  cart: [],
  currentASIN: [],
};

Telescope.prototype.initDataMgr = function () {
  // ADD TO CART
  // todo

  $(".data-cart-info-clean").bind("click", function (e) {
    e.preventDefault();
    telescope.resetData();
    location.reload();
  });

  this.addToCart = function () {
    console.log("addToCart");
    if (!$(".size-bulk").length) {
      let asin = $('.detail').attr('data-asin');
      let title = $('.asin-title').text();
      let thumb = $('.asin-image-content').attr('data-thumb');
      let price = $(".price .price-value .units").val() + "." + $(".price .price-value .decimals").val();
      price = 10.00;

      let asinItem = telescope.data.cart.find((el) => el.asin === asin);

      if (!asinItem) {
        telescope.data.cart.push({
          asin: asin,
          title: title,
          thumb: thumb,
          bulk: [{
            count: "1",
            id: "1",
            pack: "1",
            picker: 1,
            totalprice: price,
            unit: price,
            unitprice: price
          }]
        });
      } else {
        asinItem.bulk = [{
          count: "1",
          id: "1",
          pack: "1",
          picker: 1,
          totalprice: price,
          unit: price,
          unitprice: price
        }]
      }
      this.updateData();
    }
    localStorage.setItem('data', JSON.stringify(telescope.data));
    console.log("telescope data", telescope.data);
  };

  this.deleteASIN = function (id) {
    telescope.data.cart = this.data.cart.filter(d => d.asin !== id);
    this.updateData();
    location.reload();
  };

  this.deleteItem = function (id) {
    $.each(this.data.cart, function (index, asin) {
      $.each(asin.bulk, function (index, bulk) {
        if (bulk.id == id) {
          bulk.picker = 0;
        }
      });
    });
  };

  // CALCULATE BEST BULK OPTION
  // update bulk selectors
  this.getBulkProposal = function (total) {
    let asin = $('.detail').attr('data-asin');
    let asinItem = telescope.data.cart.find((el) => el.asin === asin);
    //console.log("DATA", telescope.data.cart);
    if (asinItem) {
      telescope.updatePackSelectorsAndPickers(total, asinItem);
    }
    //this.updateData();
  };


  this.getTotalPrice = function () {
    let totalprice = 0;

    let asin = $('.detail').attr('data-asin');
    let asinItem = telescope.data.cart.find((el) => el.asin === asin);

    if (asinItem) {
      $.each(asinItem.bulk, function (index2, cartBulk) {
        let pack = parseInt(cartBulk.pack);
        let picker = parseInt(cartBulk.picker) || 0;
        let unit = parseFloat(cartBulk.unitprice);
        let count = parseInt(cartBulk.count);
        totalprice += pack * picker * unit * count;
      });
      return Math.round(totalprice * 100) / 100;
    }
    return $('.sidebar .price').attr('data-totalprice');
  };

  this.getTotalCount = function () {
    let totalCount = 0;
    let totalAsins = 0;

    let asin = $('.detail').attr('data-asin');
    let asinItem = telescope.data.cart.find((el) => el.asin === asin);
    if (asinItem) {
      $.each(asinItem.bulk, function (index2, cartBulk) {
        let pack = parseInt(cartBulk.pack);
        let picker = parseInt(cartBulk.picker) || 0;
        let count = parseInt(cartBulk.count) || 0;
        totalCount += pack * picker;
        totalAsins += pack * picker * count;
      });
    }
    $(".total-count-items").html("Total Count: <b>" + totalAsins + "</b>");
    $("#popover-totals").append("Total Count: <b>" + totalAsins + "</b>");
    console.log("hi");
    
    return totalCount;
  };

  // UPDATE ASIN PRICE VALUE
  this.updateASINPrice = function () {
    let totalprice = this.getTotalPrice();
    console.log(totalprice);
    let units = Math.floor(totalprice);
    let decimals = (totalprice + '').split('.')[1];

    $('.price .units').text(units);
    $('.price .decimals').text(decimals ? decimals : 0);
  };

  // UPDATE ASIN PRICE VALUE
  this.updateQuantityPicker = function () {
    let totalCount = this.getTotalCount();
    $(".quantity-picker:not('.bulk-picker') input").val(totalCount);
  };

  this.updateTotalCart = function () {
    let totalCount = 0;
    let totalprice = 0;
    let totalItems = 0;
    $.each(this.data.cart, function (index, cartAsin) {
      $.each(cartAsin.bulk, function (index2, cartBulk) {
        let pack = parseInt(cartBulk.pack);
        let picker = parseInt(cartBulk.picker) || 0;
        let unit = parseFloat(cartBulk.unitprice);
        let count = parseInt(cartBulk.count);
        totalItems += picker;
        totalCount += pack * picker;
        totalprice += pack * picker * unit * count;
      });
    });
    $('.header-content .sub-bar .cart p').text(totalItems);
    totalprice = Math.round(totalprice * 100) / 100;
    this.data.totalCount = totalCount;
    this.data.totalprice = totalprice;
    $('.cart-number').text(totalCount + ' items');
    $('.huc-button .a-button-text').text(
      'Proceed to checkout (' + totalCount + ' items)'
    );
    $('.cart-totalprice').text('$' + totalprice);
  };

  this.updateSizePacks = function () {
    let asin = $('.detail').attr('data-asin');
    $.each($('.size-bulk-pack.active-true li'), function (index, value) {
      let id = $(value).attr('data-id');
      let asinItem = telescope.data.cart.find((el) => el.asin === asin);
      if (asinItem) {
        let bulkItem = asinItem.bulk.find((el) => el.id === id);
        if (bulkItem) {
          $(this).find('select').val(bulkItem.picker);
        } else if (id) {
          let count = $(value).attr('data-count');
          let pack = $(value).attr('data-pack');
          let unit = $(value).attr('data-unit');
          let totalprice = $(value).attr('data-totalprice');
          let unitprice = $(value).attr('data-unitprice');
          asinItem.bulk.push({
            id: id,
            picker: 0,
            count: count,
            pack: pack,
            unit: unit,
            totalprice: totalprice,
            unitprice: unitprice,
          });
        }
      }

    });

  };

  this.loadPackInfo = function () {
    var dPanel = $('.debug');
    dPanel.empty();
    $.each(this.data.cart, function (index, cartAsin) {
      $.each(cartAsin.bulk, function (index2, cartBulk) {
        var cartBulkItem = $('.size-bulk-pack-demo').clone()[0];
        $(cartBulkItem)
          .find('.pack-title')
          .text('Pack of ' + cartBulk.pack);
        $(cartBulkItem).find('.size-price').text(cartBulk.totalprice);
        $(cartBulkItem).find('.unit-price').text(cartBulk.unitprice);
        $(cartBulkItem).find('select').val(cartBulk.picker);
        dPanel.append(cartBulkItem);
      });
    });
    console.log(this.data.cart);
  };

  this.printDebugData = function () {
    $(".data-cart-info").empty();
    $.each(this.data.cart, function (index, cartAsin) {
      $(".data-cart-info").append("<h3>" + cartAsin.asin + "</h3>");
      $(".data-cart-info").append("<p>" + cartAsin.title + "</p>");
      $.each(cartAsin.bulk, function (index2, bulkItem) {
        $(".data-cart-info").append("<span class='pack-info'><b>Pack " + bulkItem.pack + "</b></span>");
        $(".data-cart-info").append("<span>Quantity: " + bulkItem.picker + " | </span>");
        $(".data-cart-info").append("<span>Count: " + bulkItem.count + " | </span>");
        $(".data-cart-info").append("<span>Unit Price: " + bulkItem.unitprice + " | </span>");
        $(".data-cart-info").append("<span>Total Price: " + bulkItem.totalprice + "</span>");
      });
      $(".data-cart-info").append("<p>JSON</p>");
      $(".data-cart-info").append("<span class='string-info'>" + JSON.stringify(cartAsin.bulk) + "</span>");
      $(".data-cart-info").append("<p> </p>");
    });
  }

  // For sidebar Details popover
  this.printDetailsData = function () {
    $("#bulk-details").empty();
    let asin = $('.detail').attr('data-asin');
    let asinItem = telescope.data.cart.find((el) => el.asin === asin);
    if (asinItem) {
      $("#bulk-details").append("<div class='pack-list'></div>");
      $.each(this.data.cart, function (index, cartAsin) {
        $.each(cartAsin.bulk, function (index2, bulkItem) {
          if (bulkItem.picker) {
            $(".pack-list").append("<span class='pack-info'>" + bulkItem.picker + "x <b>Pack of " + bulkItem.pack + "</b> (" + bulkItem.count * bulkItem.pack * bulkItem.picker + " count )</b><br/> Free Delivery: <b>Wednesday, April 4</b></span>");

          }
        });
      });
      $("#bulk-details").append("<div class ='popover-footer'>All delivery options shown at checkout</div>");
    }
  }


  // Cost Details Pop Over 

  this.printCostDetailsData = function () {
    $("#bulk-cost-details").empty();
    let asin = $('.detail').attr('data-asin');
    let asinItem = telescope.data.cart.find((el) => el.asin === asin);
    if (asinItem) {
      $("#bulk-cost-details").append("<div class='pack-cost-list'></div>");
      $.each(this.data.cart, function (index, cartAsin) {
        $.each(cartAsin.bulk, function (index2, bulkItem) {
          if (bulkItem.picker) {
            $(".pack-cost-list").append("<span class='pack-cost-info'>" + bulkItem.picker + "x <b>Pack of " + bulkItem.pack + "</b> (" +  bulkItem.count * bulkItem.pack * bulkItem.picker + " count )</b> <b class='costing'>£" + Math.round(bulkItem.totalprice *  bulkItem.picker * 100)/100 + "</b></span>");
            console.log(bulkItem.totalprice, bulkItem.picker, bulkItem.count, bulkItem.pack);
          }
        });
      });
      $("#bulk-cost-details").append("<hr>");
      $("#bulk-cost-details").append("<div id='popover-totals'></div>");

      $("#bulk-cost-details").append("<div class ='popover-footer'>Shipping costs and order total (including tax) shown at checkout</div>");
    }
  }


  // For sidebar Sellers popover

  // List of sellers 
  var sellers = ["Amazon", "Coffeelabs", "Beans Co", "Morning Inc"]

  this.printSellersData = function () {
    $("#seller-details").empty();
    let asin = $('.detail').attr('data-asin');
    let asinItem = telescope.data.cart.find((el) => el.asin === asin);
    if (asinItem) {
      $("#seller-details").append("<div class='seller-list'></div>");
      $.each(this.data.cart, function (index, cartAsin) {
        $.each(cartAsin.bulk, function (index2, bulkItem) {
          if (bulkItem.picker) {
            $(".seller-list").append("<span class='pack-info'>" + bulkItem.picker + "x <b>Pack of " + bulkItem.pack + "</b> (" + bulkItem.count * bulkItem.pack + " count )</b><br/><table><tr><td>Ships from</td><td> Amazon</td></tr><tr><td>Sold by </td><td>" + sellers[index2] + "</td></tr></table></span>");
          }
        });
      });
    }
  }

  // update Data Storage
  this.updateData = function () {
    //localStorage.setItem('data', JSON.stringify(this.data));
    this.loadPackInfo();
    this.updateSizePacks();
    this.updateTotalCart();
    this.updateASINPrice();
    this.updateQuantityPicker();
    this.cartList();
    this.printDebugData();
    this.printDetailsData();
    this.printSellersData();
    this.printCostDetailsData();

    //$(".data-viewer").html(JSON.stringify(telescope.data));
    //console.log(this.data);
  };

  this.loadLocalData = function () {
    var retrievedObject = localStorage.getItem('data');
    if (retrievedObject) {
      console.log("retrievedObject", retrievedObject);
      telescope.data = JSON.parse(retrievedObject);
    } else {
      telescope.data = originalData;
      localStorage.setItem('data', JSON.stringify(originalData));
    }
    this.updateData();
  };

  this.loadLocalData();

  // reset Data Storage
  this.resetData = function () {
    localStorage.setItem('data', JSON.stringify(originalData));
  };
};
