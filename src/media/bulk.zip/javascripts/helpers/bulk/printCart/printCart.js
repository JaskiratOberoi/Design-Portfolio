Telescope.prototype.printCart = function (id) {
  var totalItems = 0;
  var totalPrice = 0;
  $(telescope.data.cart).each(function (index, item) {
    var cartItem = $('.hidden-cart-item').clone()[0];
    $(cartItem).find('.cart-thumb img').attr('src', item.thumb);
    $(cartItem).find('.title').text(item.title);
    //console.log("item", item);
    var quantity = item.bulk.reduce(
      (sum, current) => sum + parseInt(current.pack * current.picker),
      0
    );

    $(cartItem).find('.bulk-detail .quantity').text(quantity);
    var price = item.bulk.reduce(
      (price, current) => price + parseFloat(current.totalprice * current.picker),
      0
    );
    price = Math.round(price * 100) / 100;
    $(cartItem).find('.action-delete').attr("id", item.bulk[0].id);
    $(cartItem).find('.action-delete').attr("asin", item.asin);
    $(cartItem)
      .find('.bulk-detail .count')
      .text('x ' + item.bulk[0].count + ' Count');
    $(cartItem)
      .find('.total-price')
      .text('$' + price);
    $(cartItem)
      .find('.unit-price')
      .text(
        '($' +
        Math.round((price / quantity) * item.bulk[0].count * 100) / 100 +
        '/Count)'
      );
    $('.cart-detail').append(cartItem);
    totalItems += quantity;
    totalPrice += price;
  });
  $('.subtotal').html(
    '<p>Subtotal (' +
    totalItems +
    ' items):  <span>$' +
    totalPrice +
    '</span></p>'
  );

  this.deleteItemHandler = function (item) {
    $(item).bind('click', function (e) {
      e.preventDefault();
      let asin = $(this).attr("asin");
      telescope.deleteASIN(asin);
    });
  };

};
