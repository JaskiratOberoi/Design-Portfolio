Telescope.prototype.bulkList = function () {
  var totalItems = 0;
  var totalPrice = 0;

  $(telescope.data.cart).each(function (index, item) {
    var listItem = $('.hidden-bulk-list-item').clone()[0];
    $(listItem).find('.title').text(item.title);
    var quantity = item.bulk.reduce(
      (sum, current) => sum + parseInt(current.pack),
      0
    );
    $(item.bulk).each(function (index2, bulkItem) {
      if (parseInt(bulkItem.picker))
        $(listItem)
          .find('ul')
          .append(
            '<li>' +
              bulkItem.picker +
              ' x ' +
              bulkItem.count +
              ' Count (Pack of ' +
              bulkItem.pack +
              ')</li>'
          );
    });

    var price = item.bulk.reduce(
      (price, current) => price + parseFloat(current.totalprice),
      0
    );
    $(listItem)
      .find('.bulk-detail .count')
      .text('x ' + item.bulk[0].count + ' Count');
    $(listItem)
      .find('.total-price')
      .text('$' + price);
    $(listItem)
      .find('.unit-price')
      .text(
        '($' +
          Math.round((price / quantity) * item.bulk[0].count * 100) / 100 +
          '/Count)'
      );
    $('.bulklist ul.cart-items').append(listItem);
    totalItems += quantity;
    totalPrice += price;
  });
  $('.total').html('<p>$' + totalPrice + '</p>');

  this.deleteItem = function () {};

  this.deleteItemHandler = function (item) {
    $(item).bind('click', function (e) {
      e.preventDefault();
    });
  };
};
