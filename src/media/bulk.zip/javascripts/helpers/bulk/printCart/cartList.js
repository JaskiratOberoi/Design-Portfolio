/* eslint-disable no-undef */
Telescope.prototype.cartList = function () {
  let asin = $('.detail').attr('data-asin');
  let cartList = $('.cart-list');
  cartList.empty();
  $(telescope.data.cart).each(function (index, item) {
    if (item.asin == asin) {
      $(item.bulk).each(function (index, bulkItem) {
        if (bulkItem.picker != '0')
          cartList.prepend(
            '<p id=' + bulkItem.id + '><span>· ' +
              bulkItem.picker +
              ' x Pack of ' +
              bulkItem.pack +
              '</span><span>$' +
              bulkItem.totalprice +
              '</span></p>'
          );
      });
    }
  });

};
