Telescope.prototype.availability = function () {
  $.each($(".availability"), function (key, value) {
    var weekday = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
    var someDate = new Date();
    var numberOfDaysToAdd = parseInt($(this).text());
    someDate.setDate(someDate.getDate() + numberOfDaysToAdd);
    $(".carrousel-asin").eq(0).hide();
    $(this).html(
      "<b>" + weekday[someDate.getDay()] + " " + someDate.getDate() + "</b>"
    );
  });
};
