Telescope.prototype.initExpander = function (collection) {
  $.each(collection, function( index, value ) {
    $("#" + value + " .bulkselector-item").bind("click", function (e) {
      if(!$(this).hasClass("status-disabled")){
        $(this).parent().find(".bulkselector-item").removeClass("status-selected");
        $(this).addClass("status-selected");
        let label = $(this).text();
        $(this).parents(".expander:first").find(".title").text(label);
      }
    });
  
    $("#" + value + " i").bind("click", function () {
      $(this).parents(".expander:first").toggleClass("b-open");
      $(this).parents(".expander:first").find(".b-icon").toggleClass("chevron-up").toggleClass("chevron-down");
    });

    let label = $("#" + value).find(".status-selected, .active-true > div.count-title").text();
    $("#" + value).find(".title").text(label);
  });

};

