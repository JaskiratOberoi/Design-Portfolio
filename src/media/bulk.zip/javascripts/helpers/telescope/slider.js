/**
 * [Glider : run a slider with an specific id]
 * @param  {String} id Component id
 */

Telescope.prototype.slider = function(id){
    new Glider(document.querySelector(id), {
        slidesToShow: 4,
        slidesToScroll: 4,
        draggable: false,
        arrows: {
            prev: '.slider-prev',
            next: '.slider-next'
        }
    })
}
