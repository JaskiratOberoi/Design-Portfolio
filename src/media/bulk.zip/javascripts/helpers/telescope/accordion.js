Telescope.prototype.initAccordionById = function (accordionId) {
  $("#" + accordionId + " li").bind("click", function () {
    $(this).toggleClass("b-open");
  });
};

Telescope.prototype.initBulkAccordionById = function (accordionId) {
  $("#" + accordionId + " li").bind("click", function () {
    if (!$(this).hasClass("b-open")) {
      $(".accordion .b-item").removeClass("b-open");
      $(this).addClass("b-open");
    }
  });
};
