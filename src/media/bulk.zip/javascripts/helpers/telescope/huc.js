Telescope.prototype.HUC = function (id, visible) {
  this.HUC_id = id;

  if (visible) $(".huc").show();
  else $(".huc").hide();
  
  $(".huc .cross").bind("click", function () {
    $(".huc").hide();
  });

  this.showHUC = function(){
    $(".huc").show();
  }

  this.hideHUC = function(){
    $(".huc").hide();
  }
};


