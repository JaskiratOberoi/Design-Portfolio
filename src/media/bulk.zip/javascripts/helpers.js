var Telescope = function() {
    this.redirections = [];
    this.filters = {};
    this.data = [];
    this.remoteData = undefined;
}